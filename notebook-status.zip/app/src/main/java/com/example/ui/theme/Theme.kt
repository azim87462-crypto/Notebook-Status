package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = OrangePrimary,
    onPrimary = Color.White,
    primaryContainer = PeachCard,
    onPrimaryContainer = OrangePrimary,
    secondary = OrangeSecondary,
    onSecondary = Color.White,
    secondaryContainer = CategoryChipBg,
    onSecondaryContainer = WarmDarkBrown,
    tertiary = PeachAccent,
    background = CreamBackground,
    onBackground = WarmDarkBrown,
    surface = CreamSurface,
    onSurface = WarmDarkBrown,
    surfaceVariant = PeachCard,
    onSurfaceVariant = WarmMediumBrown,
    outline = PeachBorder,
    outlineVariant = NotebookLineOrange.copy(alpha = 0.5f)
)

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFFFB74D),
    onPrimary = Color(0xFF4E1D00),
    primaryContainer = Color(0xFF5D2E0B),
    onPrimaryContainer = Color(0xFFFFDCC2),
    secondary = Color(0xFFFFAB91),
    onSecondary = Color(0xFF4E1700),
    background = Color(0xFF1E1714),
    onBackground = Color(0xFFEDE0D9),
    surface = Color(0xFF28201C),
    onSurface = Color(0xFFEDE0D9),
    surfaceVariant = Color(0xFF382D27),
    onSurfaceVariant = Color(0xFFD7C2B8),
    outline = Color(0xFF8D6E63)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // We intentionally prioritize our warm peach & orange notebook theme
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
