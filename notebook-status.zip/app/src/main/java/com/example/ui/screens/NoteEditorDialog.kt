package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Note
import com.example.ui.components.linedNotebookBackground
import com.example.ui.theme.CreamBackground
import com.example.ui.theme.OrangePrimary
import com.example.ui.theme.PeachBorder
import com.example.ui.theme.PeachCard
import com.example.ui.theme.WarmDarkBrown
import com.example.ui.theme.WarmLightBrown
import com.example.ui.theme.WarmMediumBrown

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoteEditorScreen(
    note: Note?,
    categories: List<String>,
    onSave: (id: Long, title: String, content: String, category: String, isPinned: Boolean) -> Unit,
    onClose: () -> Unit
) {
    BackHandler { onClose() }

    var title by remember { mutableStateOf(note?.title ?: "") }
    var content by remember { mutableStateOf(note?.content ?: "") }
    var selectedCategory by remember {
        mutableStateOf(note?.category ?: if (categories.any { it != "সব" }) categories.first { it != "সব" } else "দৈনিক নোট")
    }
    var isPinned by remember { mutableStateOf(note?.isPinned ?: false) }
    var showCustomCategoryDialog by remember { mutableStateOf(false) }
    var customCategoryInput by remember { mutableStateOf("") }

    val charCount = content.length
    val wordCount = remember(content) {
        if (content.isBlank()) 0 else content.trim().split("\\s+".toRegex()).size
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (note == null) "নতুন স্ট্যাটাস / নোট" else "নোট এডিট করুন",
                        style = MaterialTheme.typography.titleLarge.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onClose,
                        modifier = Modifier.testTag("editor_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "ফিরে যান (Back)",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    // Pin toggle
                    IconButton(
                        onClick = { isPinned = !isPinned },
                        modifier = Modifier.testTag("editor_pin_toggle")
                    ) {
                        Icon(
                            imageVector = if (isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            contentDescription = "Pin Note",
                            tint = if (isPinned) Color(0xFFFFD180) else Color.White.copy(alpha = 0.8f)
                        )
                    }

                    // Save Button
                    IconButton(
                        onClick = {
                            onSave(note?.id ?: 0L, title, content, selectedCategory, isPinned)
                        },
                        modifier = Modifier.testTag("editor_save_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "সংরক্ষণ করুন (Save)",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = OrangePrimary
                )
            )
        },
        containerColor = CreamBackground,
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Category Selector Section
            Text(
                text = "ক্যাটাগরি নির্বাচন করুন (Category):",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = WarmMediumBrown
                )
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Scrollable chips for category
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                categories.filter { it != "সব" }.forEach { cat ->
                    val isSelected = cat.equals(selectedCategory, ignoreCase = true)
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) OrangePrimary else PeachCard)
                            .border(
                                1.dp,
                                if (isSelected) OrangePrimary else PeachBorder,
                                RoundedCornerShape(16.dp)
                            )
                            .clickable { selectedCategory = cat }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                            .testTag("editor_category_chip_$cat")
                    ) {
                        Text(
                            text = cat,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = if (isSelected) Color.White else WarmDarkBrown,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        )
                    }
                }

                // Add new category chip
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFFFFE0B2).copy(alpha = 0.5f))
                        .border(1.dp, OrangePrimary, RoundedCornerShape(16.dp))
                        .clickable { showCustomCategoryDialog = true }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .testTag("editor_add_custom_category")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = null,
                            tint = OrangePrimary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "+ নতুন",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = OrangePrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Title Field
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("শিরোনাম (Title - ঐচ্ছিক)") },
                placeholder = { Text("যেমন: সকালের প্রেরণা / My Daily Status") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("editor_title_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = OrangePrimary,
                    unfocusedBorderColor = PeachBorder,
                    focusedLabelColor = OrangePrimary,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Word & Character count counter row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "খাতার পাতায় লিখুন (Write in Notebook):",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = WarmMediumBrown
                    )
                )

                Text(
                    text = "শব্দ: $wordCount | অক্ষর: $charCount",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = WarmLightBrown,
                        fontSize = 11.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Notebook Lined Paper Writing Pad
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.5.dp, PeachBorder, RoundedCornerShape(14.dp))
                    .background(PeachCard)
                    .linedNotebookBackground(
                        lineSpacing = 32.dp,
                        topOffset = 42.dp,
                        marginOffset = 28.dp,
                        showMarginLine = true
                    )
                    .padding(start = 32.dp, end = 12.dp, top = 8.dp, bottom = 8.dp)
            ) {
                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    placeholder = {
                        Text(
                            text = "এখানে আপনার বাংলা বা ইংরেজি স্ট্যাটাস অথবা নোট লিখুন...\n(Write your Bengali or English status here)",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = WarmLightBrown,
                                lineHeight = 24.sp
                            )
                        )
                    },
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("editor_content_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent
                    ),
                    textStyle = MaterialTheme.typography.bodyLarge.copy(
                        color = WarmDarkBrown,
                        lineHeight = 32.sp,
                        fontSize = 16.sp
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Quick templates helper for status inspiration
            Text(
                text = "দ্রুত অনুপ্রেরণা (Quick Templates):",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = WarmMediumBrown
                )
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickTemplateButton("শুভ সকাল ☀️") {
                    content = if (content.isBlank()) "শুভ সকাল! নতুন একটি দিনে নতুন আশা নিয়ে এগিয়ে চলো।" else "$content\nশুভ সকাল! ☀️"
                    selectedCategory = "অনুপ্রেরণা"
                }
                QuickTemplateButton("শুভ রাত্রি 🌙") {
                    content = if (content.isBlank()) "শান্তিময় একটি রাত ও মিষ্টি স্বপ্নের প্রত্যাশা রইল। শুভ রাত্রি!" else "$content\nশুভ রাত্রি! 🌙"
                    selectedCategory = "দৈনিক নোট"
                }
                QuickTemplateButton("অনুপ্রেরণা ✨") {
                    content = if (content.isBlank()) "কঠিন সময় সবসময় স্থায়ী হয় না, কিন্তু সাহসী মানুষরা সবসময় বিজয়ী হয়।" else "$content\nকঠিন সময় সবসময় স্থায়ী হয় না, কিন্তু সাহসী মানুষরা সবসময় বিজয়ী হয়。"
                    selectedCategory = "অনুপ্রেরণা"
                }
                QuickTemplateButton("Love Quote 💖") {
                    content = if (content.isBlank()) "You are the sweetest thought in my heart every single day." else "$content\nYou are the sweetest thought in my heart every single day."
                    selectedCategory = "ভালোবাসা"
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Bottom action buttons: Save & Clear
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TextButton(
                    onClick = {
                        title = ""
                        content = ""
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("editor_clear_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Clear,
                        contentDescription = null,
                        tint = WarmMediumBrown,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("খালি করুন (Clear)", color = WarmMediumBrown)
                }

                Button(
                    onClick = {
                        onSave(note?.id ?: 0L, title, content, selectedCategory, isPinned)
                    },
                    modifier = Modifier
                        .weight(1.5f)
                        .height(48.dp)
                        .testTag("editor_primary_save_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = OrangePrimary
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "সংরক্ষণ করুন (Save)",
                        style = MaterialTheme.typography.labelLarge.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }
    }

    // Dialog for adding custom category
    if (showCustomCategoryDialog) {
        AlertDialog(
            onDismissRequest = { showCustomCategoryDialog = false },
            title = {
                Text(
                    text = "নতুন ক্যাটাগরি তৈরি করুন",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Column {
                    Text(
                        text = "ক্যাটাগরির নাম লিখুন (যেমন: উক্তি, স্ট্যাটাস, স্মৃতি):",
                        style = MaterialTheme.typography.bodySmall.copy(color = WarmMediumBrown)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = customCategoryInput,
                        onValueChange = { customCategoryInput = it },
                        placeholder = { Text("ক্যাটাগরির নাম") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("custom_category_input"),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val trimmed = customCategoryInput.trim()
                        if (trimmed.isNotEmpty()) {
                            selectedCategory = trimmed
                            showCustomCategoryDialog = false
                            customCategoryInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
                    modifier = Modifier.testTag("confirm_custom_category_button")
                ) {
                    Text("যোগ করুন (Add)")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomCategoryDialog = false }) {
                    Text("বাতিল (Cancel)")
                }
            },
            containerColor = CreamBackground
        )
    }
}

@Composable
private fun QuickTemplateButton(
    label: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFFFFE0B2).copy(alpha = 0.5f))
            .border(0.8.dp, OrangePrimary.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = OrangePrimary,
                fontWeight = FontWeight.SemiBold
            )
        )
    }
}
