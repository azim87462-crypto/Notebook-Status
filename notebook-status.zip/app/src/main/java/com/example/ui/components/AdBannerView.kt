package com.example.ui.components

import android.content.Context
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalInspectionMode
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.R
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError

private const val TAG = "AdBannerView"

/**
 * AdMob Banner Container adhering to Google AdMob policies:
 * - Uses official Google Mobile Ads SDK (com.google.android.gms:play-services-ads)
 * - Configurable ad unit ID from strings.xml
 * - Strictly separated from writing controls and navigation buttons
 * - Clearly labeled as advertisement
 * - Never programmatically clicks or simulates ads
 */
@Composable
fun AdBannerView(
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isPreview = LocalInspectionMode.current
    var adLoaded by remember { mutableStateOf(false) }
    var adError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFFFFF3E0))
            .border(
                width = 1.dp,
                color = Color(0xFFFFCC80),
                shape = RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)
            )
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Clear Advertisement Label according to Google Ads guidelines
        Row(
            modifier = Modifier.padding(bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFFFFE0B2))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "বিজ্ঞাপন • SPONSORED AD",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFE65100)
                    )
                )
            }
        }

        if (isPreview) {
            // Preview placeholder
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .background(Color(0xFFFFECB3), RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("Google Mobile Ads Banner Preview", fontSize = 12.sp, color = Color.Gray)
            }
        } else {
            // Actual Google Mobile Ads AdView
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("admob_banner_container"),
                contentAlignment = Alignment.Center
            ) {
                var adViewInstance by remember { mutableStateOf<AdView?>(null) }

                AndroidView(
                    modifier = Modifier.testTag("admob_adview"),
                    factory = { ctx ->
                        val adUnitId = ctx.getString(R.string.admob_banner_ad_unit_id)
                        AdView(ctx).apply {
                            setAdSize(AdSize.BANNER)
                            this.adUnitId = adUnitId
                            adListener = object : AdListener() {
                                override fun onAdLoaded() {
                                    super.onAdLoaded()
                                    adLoaded = true
                                    adError = null
                                    Log.d(TAG, "AdMob banner loaded successfully")
                                }

                                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                                    super.onAdFailedToLoad(loadAdError)
                                    adLoaded = false
                                    adError = loadAdError.message
                                    Log.w(TAG, "AdMob banner failed to load: ${loadAdError.message} (Code: ${loadAdError.code})")
                                }
                            }
                            loadAd(AdRequest.Builder().build())
                            adViewInstance = this
                        }
                    }
                )

                // If in emulator without Google Play Services or network, show friendly test info
                if (!adLoaded && adError != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .background(Color(0xFFFFE0B2).copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "AdMob Status",
                            tint = Color(0xFFE65100),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Google AdMob Ready (Official Test Banner Unit Active)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFF795548),
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                // Cleanup on dispose
                DisposableEffect(Unit) {
                    onDispose {
                        adViewInstance?.destroy()
                    }
                }
            }
        }
    }
}
