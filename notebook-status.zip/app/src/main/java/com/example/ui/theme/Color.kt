package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm peach and light orange notebook palette
val OrangePrimary = Color(0xFFE65100)          // Vibrant deep orange
val OrangeSecondary = Color(0xFFF57C00)        // Warm amber orange
val PeachAccent = Color(0xFFFF8A65)            // Soft warm peach
val CreamBackground = Color(0xFFFFF9F2)        // Soft cream notebook paper
val CreamSurface = Color(0xFFFFFFFF)           // Clean white card surface
val PeachCard = Color(0xFFFFF3E0)              // Very light peach card
val WarmDarkBrown = Color(0xFF2C211B)          // Ink color for high contrast reading
val WarmMediumBrown = Color(0xFF795548)        // Secondary text
val WarmLightBrown = Color(0xFFA1887F)         // Hint text
val NotebookLineOrange = Color(0xFFFFCC80)     // Subtle ruled paper line color
val NotebookMarginRed = Color(0xFFFF8A80)      // Notebook left margin rule
val PeachBorder = Color(0xFFFFE0B2)            // Soft border color
val CategoryChipBg = Color(0xFFFFE8D6)         // Peach chip background
val CategoryChipSelected = Color(0xFFFF6F00)   // Active orange chip
