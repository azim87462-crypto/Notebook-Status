package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CreamBackground
import com.example.ui.theme.OrangePrimary
import com.example.ui.theme.WarmDarkBrown
import com.example.ui.theme.WarmMediumBrown

@Composable
fun AboutAdMobDialog(
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "AdMob Configuration Guide",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = OrangePrimary
                )
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(vertical = 4.dp)
            ) {
                Text(
                    text = "Official Google Mobile Ads SDK is integrated and currently runs in official test mode so you can safely develop without violating policy.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = WarmDarkBrown)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Where to enter your real AdMob IDs before release:",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = OrangePrimary
                    )
                )

                Spacer(modifier = Modifier.height(6.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFFFF3E0))
                        .border(1.dp, Color(0xFFFFCC80), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Column {
                        Text(
                            text = "File: app/src/main/res/values/strings.xml",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = OrangePrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "<string name=\"admob_app_id\">YOUR_REAL_APP_ID</string>\n<string name=\"admob_banner_ad_unit_id\">YOUR_REAL_BANNER_ID</string>",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = WarmDarkBrown
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Key Policy Rules Followed:",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "• Ads are never automatically clicked\n• Ad space is kept separate from writing and interactive buttons\n• Banner is clearly identified with an Ad badge\n• No fake simulated revenue",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = WarmMediumBrown,
                        lineHeight = 18.sp
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = OrangePrimary),
                modifier = Modifier.testTag("dismiss_admob_guide_button")
            ) {
                Text("বুঝেছি (Got it)")
            }
        },
        containerColor = CreamBackground
    )
}
