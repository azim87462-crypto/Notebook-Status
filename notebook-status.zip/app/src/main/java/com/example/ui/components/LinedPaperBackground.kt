package com.example.ui.components

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.NotebookLineOrange
import com.example.ui.theme.NotebookMarginRed

/**
 * Modifier that renders notebook paper ruling lines and margin line.
 */
fun Modifier.linedNotebookBackground(
    lineSpacing: Dp = 32.dp,
    topOffset: Dp = 40.dp,
    marginOffset: Dp = 32.dp,
    showMarginLine: Boolean = true,
    lineColor: Color = NotebookLineOrange.copy(alpha = 0.45f),
    marginColor: Color = NotebookMarginRed.copy(alpha = 0.35f)
): Modifier = this.drawBehind {
    val lineSpacingPx = lineSpacing.toPx()
    val topOffsetPx = topOffset.toPx()
    val marginOffsetPx = marginOffset.toPx()

    // Left vertical margin line
    if (showMarginLine) {
        drawLine(
            color = marginColor,
            start = Offset(marginOffsetPx, 0f),
            end = Offset(marginOffsetPx, size.height),
            strokeWidth = 1.5.dp.toPx()
        )
    }

    // Horizontal notebook writing lines
    var currentY = topOffsetPx
    while (currentY < size.height) {
        drawLine(
            color = lineColor,
            start = Offset(0f, currentY),
            end = Offset(size.width, currentY),
            strokeWidth = 1.dp.toPx()
        )
        currentY += lineSpacingPx
    }
}
