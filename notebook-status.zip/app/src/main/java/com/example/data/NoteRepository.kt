package com.example.data

import kotlinx.coroutines.flow.Flow

/**
 * Repository abstracting note data access operations.
 */
class NoteRepository(private val noteDao: NoteDao) {

    val allNotes: Flow<List<Note>> = noteDao.getAllNotes()

    val allCategories: Flow<List<String>> = noteDao.getAllCategories()

    suspend fun getNoteById(id: Long): Note? = noteDao.getNoteById(id)

    suspend fun insertNote(note: Note): Long = noteDao.insertNote(note)

    suspend fun insertNotes(notes: List<Note>) = noteDao.insertNotes(notes)

    suspend fun updateNote(note: Note) = noteDao.updateNote(note)

    suspend fun deleteNote(note: Note) = noteDao.deleteNote(note)

    suspend fun deleteNoteById(id: Long) = noteDao.deleteNoteById(id)

    suspend fun getNoteCount(): Int = noteDao.getNoteCount()
}
