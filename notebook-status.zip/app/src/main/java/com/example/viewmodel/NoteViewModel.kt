package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.Note
import com.example.data.NoteRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class NoteUiState(
    val notes: List<Note> = emptyList(),
    val filteredNotes: List<Note> = emptyList(),
    val categories: List<String> = emptyList(),
    val selectedCategory: String = "সব",
    val searchQuery: String = "",
    val editingNote: Note? = null,
    val isEditorVisible: Boolean = false,
    val isAboutAdMobVisible: Boolean = false,
    val userNotice: String? = null
)

class NoteViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: NoteRepository

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("সব")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _editingNote = MutableStateFlow<Note?>(null)
    val editingNote: StateFlow<Note?> = _editingNote.asStateFlow()

    private val _isEditorVisible = MutableStateFlow(false)
    val isEditorVisible: StateFlow<Boolean> = _isEditorVisible.asStateFlow()

    private val _isAboutAdMobVisible = MutableStateFlow(false)
    val isAboutAdMobVisible: StateFlow<Boolean> = _isAboutAdMobVisible.asStateFlow()

    private val _userNotice = MutableStateFlow<String?>(null)
    val userNotice: StateFlow<String?> = _userNotice.asStateFlow()

    // Default pre-loaded category options
    private val defaultCategories = listOf(
        "সব",
        "অনুপ্রেরণা",
        "ভালোবাসা",
        "কষ্ট",
        "ইসলামিক",
        "বন্ধুত্ব",
        "জীবন",
        "দৈনিক নোট",
        "English Quotes"
    )

    val uiState: StateFlow<NoteUiState>

    init {
        val noteDao = AppDatabase.getDatabase(application).noteDao()
        repository = NoteRepository(noteDao)

        // Seed initial friendly Bengali & English statuses if database is brand new
        viewModelScope.launch {
            if (repository.getNoteCount() == 0) {
                seedInitialNotes()
            }
        }

        val categoriesFlow: Flow<List<String>> = repository.allCategories.map { dbCats ->
            val set = linkedSetOf("সব")
            set.addAll(defaultCategories.filter { it != "সব" })
            set.addAll(dbCats.filter { it.isNotBlank() && it != "সব" })
            set.toList()
        }

        // Combine notes with query and selected category (3 flows)
        val filteredNotesFlow = combine(
            repository.allNotes,
            _searchQuery,
            _selectedCategory
        ) { allNotes, query, selectedCat ->
            val filtered = allNotes.filter { note ->
                val matchesCategory = (selectedCat == "সব" || note.category.equals(selectedCat, ignoreCase = true))
                val matchesQuery = query.isBlank() ||
                        note.title.contains(query, ignoreCase = true) ||
                        note.content.contains(query, ignoreCase = true) ||
                        note.category.contains(query, ignoreCase = true)
                matchesCategory && matchesQuery
            }
            Pair(allNotes, filtered)
        }

        // Combine dialog and notice state (4 flows)
        val dialogStateFlow = combine(
            _editingNote,
            _isEditorVisible,
            _isAboutAdMobVisible,
            _userNotice
        ) { editingNote, isEditorVisible, isAboutAdMob, notice ->
            DialogState(editingNote, isEditorVisible, isAboutAdMob, notice)
        }

        // Combine into final NoteUiState (4 flows)
        uiState = combine(
            filteredNotesFlow,
            categoriesFlow,
            _selectedCategory,
            dialogStateFlow
        ) { notesPair, categories, selectedCat, dialogState ->
            NoteUiState(
                notes = notesPair.first,
                filteredNotes = notesPair.second,
                categories = categories,
                selectedCategory = selectedCat,
                searchQuery = _searchQuery.value,
                editingNote = dialogState.editingNote,
                isEditorVisible = dialogState.isEditorVisible,
                isAboutAdMobVisible = dialogState.isAboutAdMob,
                userNotice = dialogState.notice
            )
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = NoteUiState(categories = defaultCategories)
        )
    }

    private data class DialogState(
        val editingNote: Note?,
        val isEditorVisible: Boolean,
        val isAboutAdMob: Boolean,
        val notice: String?
    )

    fun onSearchQueryChange(newQuery: String) {
        _searchQuery.value = newQuery
    }

    fun onCategorySelect(category: String) {
        _selectedCategory.value = category
    }

    fun openNewNoteEditor(defaultCategory: String = "") {
        _editingNote.value = null
        _isEditorVisible.value = true
    }

    fun openEditNoteEditor(note: Note) {
        _editingNote.value = note
        _isEditorVisible.value = true
    }

    fun closeEditor() {
        _isEditorVisible.value = false
        _editingNote.value = null
    }

    fun showAboutAdMob(show: Boolean) {
        _isAboutAdMobVisible.value = show
    }

    fun clearUserNotice() {
        _userNotice.value = null
    }

    fun saveNote(
        id: Long = 0,
        title: String,
        content: String,
        category: String,
        isPinned: Boolean = false
    ) {
        val trimmedTitle = title.trim()
        val trimmedContent = content.trim()
        val finalCategory = if (category.trim().isBlank()) "দৈনিক নোট" else category.trim()

        if (trimmedContent.isEmpty()) {
            _userNotice.value = "অনুগ্রহ করে কিছু লিখুন (Please write something)"
            return
        }

        viewModelScope.launch {
            val now = System.currentTimeMillis()
            if (id == 0L) {
                val newNote = Note(
                    title = trimmedTitle,
                    content = trimmedContent,
                    category = finalCategory,
                    isPinned = isPinned,
                    createdAt = now,
                    updatedAt = now
                )
                repository.insertNote(newNote)
                _userNotice.value = "নোট সফলভাবে সংরক্ষণ করা হয়েছে! (Saved successfully)"
            } else {
                val existingNote = repository.getNoteById(id)
                val updatedNote = (existingNote ?: Note(id = id, title = trimmedTitle, content = trimmedContent, category = finalCategory)).copy(
                    title = trimmedTitle,
                    content = trimmedContent,
                    category = finalCategory,
                    isPinned = isPinned,
                    updatedAt = now
                )
                repository.updateNote(updatedNote)
                _userNotice.value = "নোট সফলভাবে আপডেট করা হয়েছে! (Updated successfully)"
            }
            closeEditor()
        }
    }

    fun togglePin(note: Note) {
        viewModelScope.launch {
            val updated = note.copy(isPinned = !note.isPinned, updatedAt = System.currentTimeMillis())
            repository.updateNote(updated)
            _userNotice.value = if (updated.isPinned) "পিন করা হয়েছে (Pinned)" else "আনপিন করা হয়েছে (Unpinned)"
        }
    }

    fun deleteNote(note: Note) {
        viewModelScope.launch {
            repository.deleteNote(note)
            _userNotice.value = "নোট মুছে ফেলা হয়েছে (Note deleted)"
        }
    }

    private suspend fun seedInitialNotes() {
        val now = System.currentTimeMillis()
        val sampleNotes = listOf(
            Note(
                title = "সাফল্যের মূলমন্ত্র",
                content = "হাল ছেড়ে দেওয়া পৃথিবীর সবচেয়ে সহজ কাজ, কিন্তু যে ব্যক্তি শেষ পর্যন্ত চেষ্টা করে যায়, সাফল্য তার পদচুম্বন করে। প্রতিটি ব্যর্থতাই নতুনভাবে শুরু করার অনুপ্রেরণা।",
                category = "অনুপ্রেরণা",
                isPinned = true,
                createdAt = now - 50000,
                updatedAt = now - 50000
            ),
            Note(
                title = "Believe in Yourself",
                content = "Every sunrise brings a new page in your notebook of life. Write a story full of courage, kindness, and perseverance. You are capable of amazing things!",
                category = "English Quotes",
                isPinned = true,
                createdAt = now - 40000,
                updatedAt = now - 40000
            ),
            Note(
                title = "হৃদয়ের কথা",
                content = "ভালোবাসা হলো এমন এক মিষ্টি অনুভূতি যা কোনো শর্ত মানে না। শুধু পাশে থাকার নিশ্চয়তা আর একজন আরেকজনের মুখে হাসি ফোটানোর তীব্র ইচ্ছা।",
                category = "ভালোবাসা",
                isPinned = false,
                createdAt = now - 30000,
                updatedAt = now - 30000
            ),
            Note(
                title = "বন্ধুত্বের মূল্য",
                content = "হাজারটা সাধারণ বন্ধুর চেয়ে এমন একজন বন্ধু থাকা ভালো, যে তোমার নীরবতার ভাষাও বুঝতে পারে এবং বিপদের দিনে ছায়ার মতো পাশে দাঁড়ায়।",
                category = "বন্ধুত্ব",
                isPinned = false,
                createdAt = now - 20000,
                updatedAt = now - 20000
            ),
            Note(
                title = "শান্তির বাণী",
                content = "ধৈর্য হলো এমন একটি গাছ, যার সারা গায়ে কাঁটা থাকে কিন্তু তার ফল হয় অত্যন্ত সুমিষ্ট। আল্লাহর উপর ভরসা রাখো, তিনি উত্তম পরিকল্পনাকারী।",
                category = "ইসলামিক",
                isPinned = false,
                createdAt = now - 10000,
                updatedAt = now - 10000
            )
        )
        repository.insertNotes(sampleNotes)
    }
}
