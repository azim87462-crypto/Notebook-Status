package com.example

import com.example.data.Note
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NoteUnitTest {

    @Test
    fun noteEntity_creationAndPinState() {
        val note = Note(
            id = 1L,
            title = "অনুপ্রেরণা",
            content = "কখনো আশা হারাবেন না।",
            category = "অনুপ্রেরণা",
            isPinned = false
        )

        assertEquals("অনুপ্রেরণা", note.title)
        assertEquals("কখনো আশা হারাবেন না।", note.content)
        assertEquals("অনুপ্রেরণা", note.category)
        assertFalse(note.isPinned)

        val pinnedNote = note.copy(isPinned = true)
        assertTrue(pinnedNote.isPinned)
    }

    @Test
    fun noteSearchFilter_matchesBengaliAndEnglish() {
        val notes = listOf(
            Note(1L, "সাফল্য", "পরিশ্রম কখনো বৃথা যায় না", "অনুপ্রেরণা"),
            Note(2L, "Love", "You make my days brighter", "ভালোবাসা"),
            Note(3L, "শান্তি", "সবর ধারণ করুন", "ইসলামিক")
        )

        val bengaliMatch = notes.filter { it.content.contains("পরিশ্রম") }
        assertEquals(1, bengaliMatch.size)
        assertEquals("সাফল্য", bengaliMatch.first().title)

        val englishMatch = notes.filter { it.content.contains("brighter") }
        assertEquals(1, englishMatch.size)
        assertEquals("Love", englishMatch.first().title)
    }
}
